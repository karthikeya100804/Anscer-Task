# generated from genmsg/cmake/pkg-msg-paths.cmake.develspace.in

set(anscer_nav_MSG_INCLUDE_DIRS "/home/vboxuser/catkin_ws/devel/share/anscer_nav/msg")
set(anscer_nav_MSG_DEPENDENCIES actionlib_msgs;geometry_msgs;nav_msgs;std_msgs)
