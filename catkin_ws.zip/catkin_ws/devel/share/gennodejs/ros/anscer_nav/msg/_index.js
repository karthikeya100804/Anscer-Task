
"use strict";

let NavigateToMapAction = require('./NavigateToMapAction.js');
let NavigateToMapGoal = require('./NavigateToMapGoal.js');
let NavigateToMapActionGoal = require('./NavigateToMapActionGoal.js');
let NavigateToMapResult = require('./NavigateToMapResult.js');
let NavigateToMapActionFeedback = require('./NavigateToMapActionFeedback.js');
let NavigateToMapFeedback = require('./NavigateToMapFeedback.js');
let NavigateToMapActionResult = require('./NavigateToMapActionResult.js');

module.exports = {
  NavigateToMapAction: NavigateToMapAction,
  NavigateToMapGoal: NavigateToMapGoal,
  NavigateToMapActionGoal: NavigateToMapActionGoal,
  NavigateToMapResult: NavigateToMapResult,
  NavigateToMapActionFeedback: NavigateToMapActionFeedback,
  NavigateToMapFeedback: NavigateToMapFeedback,
  NavigateToMapActionResult: NavigateToMapActionResult,
};
