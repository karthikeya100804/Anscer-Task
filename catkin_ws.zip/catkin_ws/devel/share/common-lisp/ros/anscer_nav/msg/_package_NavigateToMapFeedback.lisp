(cl:in-package anscer_nav-msg)
(cl:export '(STATUS-VAL
          STATUS
))