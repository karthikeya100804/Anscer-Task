(cl:in-package anscer_nav-msg)
(cl:export '(X-VAL
          X
          Y-VAL
          Y
          TARGET_MAP-VAL
          TARGET_MAP
))