; Auto-generated. Do not edit!


(cl:in-package anscer_nav-msg)


;//! \htmlinclude NavigateToMapGoal.msg.html

(cl:defclass <NavigateToMapGoal> (roslisp-msg-protocol:ros-message)
  ((x
    :reader x
    :initarg :x
    :type cl:float
    :initform 0.0)
   (y
    :reader y
    :initarg :y
    :type cl:float
    :initform 0.0)
   (target_map
    :reader target_map
    :initarg :target_map
    :type cl:string
    :initform ""))
)

(cl:defclass NavigateToMapGoal (<NavigateToMapGoal>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <NavigateToMapGoal>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'NavigateToMapGoal)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name anscer_nav-msg:<NavigateToMapGoal> is deprecated: use anscer_nav-msg:NavigateToMapGoal instead.")))

(cl:ensure-generic-function 'x-val :lambda-list '(m))
(cl:defmethod x-val ((m <NavigateToMapGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader anscer_nav-msg:x-val is deprecated.  Use anscer_nav-msg:x instead.")
  (x m))

(cl:ensure-generic-function 'y-val :lambda-list '(m))
(cl:defmethod y-val ((m <NavigateToMapGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader anscer_nav-msg:y-val is deprecated.  Use anscer_nav-msg:y instead.")
  (y m))

(cl:ensure-generic-function 'target_map-val :lambda-list '(m))
(cl:defmethod target_map-val ((m <NavigateToMapGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader anscer_nav-msg:target_map-val is deprecated.  Use anscer_nav-msg:target_map instead.")
  (target_map m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <NavigateToMapGoal>) ostream)
  "Serializes a message object of type '<NavigateToMapGoal>"
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'x))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'y))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'target_map))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'target_map))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <NavigateToMapGoal>) istream)
  "Deserializes a message object of type '<NavigateToMapGoal>"
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'x) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'y) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'target_map) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'target_map) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<NavigateToMapGoal>)))
  "Returns string type for a message object of type '<NavigateToMapGoal>"
  "anscer_nav/NavigateToMapGoal")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'NavigateToMapGoal)))
  "Returns string type for a message object of type 'NavigateToMapGoal"
  "anscer_nav/NavigateToMapGoal")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<NavigateToMapGoal>)))
  "Returns md5sum for a message object of type '<NavigateToMapGoal>"
  "706a3e627bc6a486023114ea360ee382")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'NavigateToMapGoal)))
  "Returns md5sum for a message object of type 'NavigateToMapGoal"
  "706a3e627bc6a486023114ea360ee382")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<NavigateToMapGoal>)))
  "Returns full string definition for message of type '<NavigateToMapGoal>"
  (cl:format cl:nil "# ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======~%# Goal~%float64 x~%float64 y~%string target_map~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'NavigateToMapGoal)))
  "Returns full string definition for message of type 'NavigateToMapGoal"
  (cl:format cl:nil "# ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======~%# Goal~%float64 x~%float64 y~%string target_map~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <NavigateToMapGoal>))
  (cl:+ 0
     8
     8
     4 (cl:length (cl:slot-value msg 'target_map))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <NavigateToMapGoal>))
  "Converts a ROS message object to a list"
  (cl:list 'NavigateToMapGoal
    (cl:cons ':x (x msg))
    (cl:cons ':y (y msg))
    (cl:cons ':target_map (target_map msg))
))
