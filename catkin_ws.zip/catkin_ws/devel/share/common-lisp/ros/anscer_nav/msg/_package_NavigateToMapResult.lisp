(cl:in-package anscer_nav-msg)
(cl:export '(SUCCESS-VAL
          SUCCESS
))