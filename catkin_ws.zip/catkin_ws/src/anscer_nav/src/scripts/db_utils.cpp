#include "anscer_nav/db_utils.h"
#include <sqlite3.h>
#include <iostream>

/// This function looks into the wormholes.db SQLite file to find the (x, y) coordinates
/// of a wormhole between two maps. If nothing is found, it returns (-1.0, -1.0)
std::pair<double, double> getWormholeCoordinates(const std::string& from_map, const std::string& to_map) {
    sqlite3* db;
    sqlite3_stmt* stmt;
    
    // By default, assume no wormhole found (return -1.0, -1.0)
    std::pair<double, double> coords(-1.0, -1.0);  

    // Open the wormhole database (hardcoded path — you can improve this later)
    int rc = sqlite3_open("/home/vboxuser/catkin_ws/src/anscer_nav/wormholes.db", &db);
    if (rc) {
        std::cerr << "Couldn't open wormhole DB: " << sqlite3_errmsg(db) << std::endl;
        return coords;
    }

    // SQL query to find x, y coordinates between the two given maps
    std::string query = "SELECT x, y FROM wormholes WHERE from_map=? AND to_map=?;";
    
    // Prepare the SQL statement
    rc = sqlite3_prepare_v2(db, query.c_str(), -1, &stmt, 0);
    if (rc != SQLITE_OK) {
        std::cerr << "Query preparation failed\n";
        sqlite3_close(db);
        return coords;
    }

    // Bind map names to the placeholders in the query
    sqlite3_bind_text(stmt, 1, from_map.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, to_map.c_str(), -1, SQLITE_STATIC);

    // Execute the query — if we get a row, extract x and y
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        coords.first = sqlite3_column_double(stmt, 0);  // x
        coords.second = sqlite3_column_double(stmt, 1); // y
    } else {
        // If we didn’t find a match, let the user know
        std::cerr << "No wormhole found from " << from_map << " to " << to_map << std::endl;
    }

    // Always clean up the statement and close the DB
    sqlite3_finalize(stmt);
    sqlite3_close(db);

    // Return the wormhole coordinates (or -1.0, -1.0 if not found)
    return coords;
}
