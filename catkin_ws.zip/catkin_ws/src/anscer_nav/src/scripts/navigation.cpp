#include "ros/ros.h"
#include <actionlib/server/simple_action_server.h>
#include <actionlib/client/simple_action_client.h>
#include <move_base_msgs/MoveBaseAction.h>
#include "anscer_nav/NavigateToMapAction.h"
#include "anscer_nav/db_utils.h"

// This class handles the main logic of receiving navigation goals and managing map transitions
class NavigationServer {
protected:
    ros::NodeHandle nh_;  // Main ROS handle for parameters and communication
    actionlib::SimpleActionServer<anscer_nav::NavigateToMapAction> as_;  // Our custom action server
    std::string action_name_;  // Just storing the action name for display/logging

public:
    // Constructor: setup the action server and start it
    NavigationServer(std::string name) :
        as_(nh_, name, boost::bind(&NavigationServer::executeCB, this, _1), false),
        action_name_(name)
    {
        as_.start();  // Action server is now ready to receive goals
        ROS_INFO("NavigateToMap action server started.");
    }

    // This is the main callback that runs every time a new goal is received
    void executeCB(const anscer_nav::NavigateToMapGoalConstPtr &goal) {
        std::string current_map;
        nh_.getParam("/current_map", current_map);  // Read which map is currently active

        // Log the incoming goal
        ROS_INFO("Goal received: map [%s], x = %.2f, y = %.2f", goal->target_map.c_str(), goal->x, goal->y);

        // Build the pose message (goal position) to send to move_base
        geometry_msgs::PoseStamped target_pose;
        target_pose.header.frame_id = "map";
        target_pose.pose.position.x = goal->x;
        target_pose.pose.position.y = goal->y;
        target_pose.pose.orientation.w = 1.0;  // Facing forward

        // Create a move_base client to send the navigation goal
        actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> ac("move_base", true);
        ac.waitForServer();  // Wait until move_base is ready

        // If the goal is in the same map, we send it directly
        if (current_map == goal->target_map) {
            ROS_INFO("Same map: sending goal to move_base");
            sendGoal(ac, target_pose);
        } 
        // If the goal is in a different map, we must go to the wormhole first
        else {
            ROS_INFO("Different map: navigating to wormhole");
            auto wormhole = getWormholeCoordinates(current_map, goal->target_map);

            // If wormhole not found in DB, stop the goal
            if (wormhole.first == -1.0) {
                ROS_ERROR("No wormhole found.");
                as_.setAborted();
                return;
            }

            // Create a pose for the wormhole location
            geometry_msgs::PoseStamped wormhole_pose;
            wormhole_pose.header.frame_id = "map";
            wormhole_pose.pose.position.x = wormhole.first;
            wormhole_pose.pose.position.y = wormhole.second;
            wormhole_pose.pose.orientation.w = 1.0;

            // First go to the wormhole
            sendGoal(ac, wormhole_pose);

            // Simulate switching maps by updating the parameter
            ROS_INFO("Switching maps from [%s] to [%s]", current_map.c_str(), goal->target_map.c_str());
            nh_.setParam("/current_map", goal->target_map);

            // Pause briefly to simulate time taken for relocalization
            ros::Duration(3.0).sleep();

            // Now go to the actual goal in the new map
            sendGoal(ac, target_pose);
        }

        // If all went well, tell the client it was successful
        anscer_nav::NavigateToMapResult result;
        result.success = true;
        as_.setSucceeded(result);
    }

    // Helper function to send a goal to move_base and wait for result
    void sendGoal(actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> &ac, const geometry_msgs::PoseStamped &pose) {
        move_base_msgs::MoveBaseGoal move_goal;
        move_goal.target_pose = pose;

        ac.sendGoal(move_goal);  // Send goal to move_base
        ac.waitForResult();      // Block until done

        if (ac.getState() != actionlib::SimpleClientGoalState::SUCCEEDED) {
            ROS_WARN("Failed to reach goal");  // Navigation failed
        } else {
            ROS_INFO("Reached goal successfully.");  // Navigation succeeded
        }
    }
};

// Main function: start ROS and launch the navigation server
int main(int argc, char** argv) {
    ros::init(argc, argv, "navigation_node");
    NavigationServer server("navigate_to_map");  // Start the custom action server
    ros::spin();  // Keep the node alive and listening for goals
    return 0;
}
