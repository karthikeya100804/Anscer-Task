#include <ros/ros.h>
#include "anscer_nav/db_utils.h"
#include <iostream>

int main(int argc, char** argv) {
    ros::init(argc, argv, "wormhole_test");
    ros::NodeHandle nh;  
    
    auto coords = getWormholeCoordinates("room1", "room2");
    ROS_INFO("Wormhole from room1 to room2: x=%.2f, y=%.2f", coords.first, coords.second);
    
    return 0;
}