#ifndef DB_UTILS_H
#define DB_UTILS_H

#include <string>
#include <utility>

/// Looks up wormhole coordinates from an SQLite database.
/// param from_map The current map name (e.g., "room1")
/// param to_map The destination map name (e.g., "room2")
/// return A pair of doubles representing the wormhole’s (x, y) coordinates.
std::pair<double, double> getWormholeCoordinates(const std::string& from_map, const std::string& to_map);

#endif  
